﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Components;

namespace GamingIsLove.ORKFramework.Components
{
	[AddComponentMenu("ORK Framework/Combatant/Combatant Despawner")]
	public class CombatantDespawner : SerializedBehaviour<CombatantDespawner.Settings>
	{
		// in-game
		protected bool registered = false;

		protected List<Combatant> combatants = new List<Combatant>();

		protected List<Combatant> despawnedCombatants;

		protected Dictionary<Combatant, DespawnInfo> time;

		protected virtual void OnEnable()
		{
			if(ORK.Initialized)
			{
				this.Register();
			}
		}

		protected virtual void Start()
		{
			if(this.settings.checkDistance ||
				this.settings.afterTime)
			{
				if(this.settings.checkDistance &&
					this.settings.respawn)
				{
					this.despawnedCombatants = new List<Combatant>();
				}
				if(this.settings.afterTime)
				{
					this.time = new Dictionary<Combatant, DespawnInfo>();
				}

				this.Register();
			}
			else
			{
				this.enabled = false;
			}
		}

		protected virtual void OnDisable()
		{
			this.Unregister();
		}

		public virtual void Register()
		{
			if(!this.registered &&
				(this.settings.checkDistance ||
					this.settings.afterTime))
			{
				ORK.Game.Combatants.Added += this.AddCombatant;
				ORK.Game.Combatants.Removed += this.RemoveCombatant;
				this.registered = true;
			}
		}

		public virtual void Unregister()
		{
			if(this.registered)
			{
				ORK.Game.Combatants.Added -= this.AddCombatant;
				ORK.Game.Combatants.Removed -= this.RemoveCombatant;
				this.registered = false;
			}
		}

		public virtual void AddCombatant(Combatant combatant)
		{
			if(!combatant.Group.IsPlayerGroup() &&
				(combatant.Group.IsEnemy(ORK.Game.ActiveGroup.Leader) ?
					this.settings.despawnEnemies :
					this.settings.despawnAllies) &&
				!this.combatants.Contains(combatant))
			{
				this.combatants.Add(combatant);

				if(this.settings.afterTime)
				{
					this.time.Add(combatant, new DespawnInfo(this.settings.time.GetValue(combatant.Call)));
				}
			}
		}

		public virtual void RemoveCombatant(Combatant combatant)
		{
			if(this.combatants.Contains(combatant))
			{
				this.combatants.Remove(combatant);
				if(this.settings.afterTime)
				{
					this.time.Remove(combatant);
				}
			}
		}


		/*
		============================================================================
		Update functions
		============================================================================
		*/
		protected virtual void LateUpdate()
		{
			if(this.settings.checkDistance)
			{
				Combatant player = ORK.Game.ActiveGroup.Leader;
				if(player != null)
				{
					if(this.settings.afterTime)
					{
						float delta = Time.deltaTime;

						for(int i = 0; i < this.combatants.Count; i++)
						{
							Combatant combatant = this.combatants[i];
							if(this.settings.range.OutOfRange(player.GameObject, combatant.GameObject))
							{
								DespawnInfo info = null;
								if(this.time.TryGetValue(combatant, out info))
								{
									info.outOfRange = true;
									info.time -= delta;
									if(info.time <= 0)
									{
										this.combatants.RemoveAt(i--);
										this.time.Remove(combatant);

										if(this.settings.respawn)
										{
											combatant.GameObject.SetActive(false);
											this.despawnedCombatants.Add(combatant);
										}
										else
										{
											GameObject.Destroy(combatant.GameObject);
										}
									}
								}
							}
							else if(this.settings.resetTime)
							{
								DespawnInfo info = null;
								if(this.time.TryGetValue(combatant, out info) &&
									info.outOfRange &&
									this.settings.range.InRange(player.GameObject, combatant.GameObject))
								{
									info.outOfRange = false;
									info.time = this.settings.time.GetValue(combatant.Call);
								}
							}
						}
					}
					else
					{
						for(int i = 0; i < this.combatants.Count; i++)
						{
							Combatant combatant = this.combatants[i];
							if(this.settings.range.OutOfRange(player.GameObject, combatant.GameObject))
							{
								this.combatants.RemoveAt(i--);

								if(this.settings.respawn)
								{
									combatant.GameObject.SetActive(false);
									this.despawnedCombatants.Add(combatant);
								}
								else
								{
									GameObject.Destroy(combatant.GameObject);
								}
							}
						}
					}

					// repsawn
					if(this.settings.respawn)
					{
						for(int i = 0; i < this.despawnedCombatants.Count; i++)
						{
							Combatant combatant = this.despawnedCombatants[i];
							if(this.settings.range.InRange(player.GameObject, combatant.GameObject))
							{
								this.despawnedCombatants.RemoveAt(i--);
								combatant.GameObject.SetActive(true);
								combatant.Animations.UpdateAnimations();
							}
							else if(this.settings.useDestroyRange &&
								this.settings.destroyRange.OutOfRange(player.GameObject, combatant.GameObject))
							{
								this.despawnedCombatants.RemoveAt(i--);
								GameObject.Destroy(combatant.GameObject);
							}
						}
					}
				}
			}
			else if(this.settings.afterTime)
			{
				float delta = Time.deltaTime;

				for(int i = 0; i < this.combatants.Count; i++)
				{
					Combatant combatant = this.combatants[i];
					DespawnInfo info = null;
					if(this.time.TryGetValue(combatant, out info))
					{
						info.time -= delta;
						if(info.time <= 0)
						{
							this.combatants.RemoveAt(i--);
							this.time.Remove(combatant);
							GameObject.Destroy(combatant.GameObject);
						}
					}
				}
			}
		}

		protected class DespawnInfo
		{
			public float time = 0;

			public bool outOfRange = false;

			public DespawnInfo(float time)
			{
				this.time = time;
			}
		}


		/*
		============================================================================
		Settings
		============================================================================
		*/
		public class Settings : BaseData
		{
			// factions
			[EditorHelp("Despawn Allies (non-player)", "Allies of the player will be despawned.\n" +
				"This doesn't include members of the player group.", "")]
			public bool despawnAllies = true;

			[EditorHelp("Despawn Enemies", "Enemies of the palyer will be despawned.", "")]
			public bool despawnEnemies = true;


			// distance
			[EditorHelp("Check Distance", "Despawn combatants when getting out of a defined range of the player.", "")]
			[EditorFoldout("Distance", "Optionally despawn combatants when they get out of a defined range of the player.", "")]
			public bool checkDistance = false;

			[EditorIndent]
			[EditorCondition("checkDistance", true)]
			public RangeValue range = new RangeValue(10);

			// respawn
			[EditorHelp("Respawn In Range", "Respawn the combatants when their last position is within range of the player.\n" +
				"Despawned combatants will only disable the game object to reenable it when getting into range again.", "")]
			[EditorSeparator]
			public bool respawn = false;

			[EditorHelp("Destroy Range", "Permanently remove combatants when they're out of a defined range of the player.", "")]
			[EditorCondition("respawn", true)]
			public bool useDestroyRange = false;

			[EditorIndent]
			[EditorEndFoldout]
			[EditorCondition("useDestroyRange", true)]
			[EditorEndCondition(3)]
			public RangeValue destroyRange = new RangeValue(50);


			// time
			[EditorHelp("Despawn After Time", "Despawn combatants after a defined amount of time (in seconds).\n" +
				"Combined with 'Check Distance', the despawn timer is only counted when a combatant is out of range.", "")]
			[EditorFoldout("Despawn After Time", "", "")]
			public bool afterTime = false;

			[EditorHelp("Reset Time", "Reset the despawn time each time a combatant moves out of range again.", "")]
			[EditorCondition(new string[] { "checkDistance", "afterTime" },
				new object[] { true, true })]
			[EditorEndCondition]
			public bool resetTime = false;

			[EditorHelp("Despawn Time (s)", "The time in seconds until the combatant is despawned.")]
			[EditorEndFoldout]
			[EditorCondition("afterTime", true)]
			[EditorEndCondition]
			public FloatValue<GameObjectSelection> time = new FloatValue<GameObjectSelection>(10);

			public Settings()
			{

			}
		}
	}
}
