﻿
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Schematics;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework.Components
{
	[AddComponentMenu("ORK Framework/Battle/Target Raycast Cursor: Schematic")]
	public class SchematicTargetRaycastCursorPrefab : MonoBehaviour, ITargetRaycastCursorPrefab
	{
		[Tooltip("Select the schematic used when starting the raycast target selection (spawning the prefab).\n" +
			"The user (combatant) is available as 'Machine Object' and 'Starting Object' of the schematic.\n" +
			"The ability or item using the raycast is available as local selected data via the data key 'action'.\n" +
			"The game object of the cursor is available as local selected data via the data key 'cursor'.")]
		public MakinomSchematicAsset startSchematicAsset;

		[Tooltip("Select the schematic used when stopping the raycast target selection (destroying the prefab).\n" +
			"The user (combatant) is available as 'Machine Object' and 'Starting Object' of the schematic.\n" +
			"The ability or item using the raycast is available as local selected data via the data key 'action'.\n" +
			"The game object of the cursor is available as local selected data via the data key 'cursor'.")]
		public MakinomSchematicAsset stopSchematicAsset;


		// in-game
		protected Combatant user;

		protected BaseAction action;

		public virtual void StartSelection(Combatant user, BaseAction action)
		{
			this.user = user;
			this.action = action;

			if(this.startSchematicAsset != null)
			{
				Schematic.Play(this.startSchematicAsset, this, null, this.user, this.user, false, null,
					this.CreateSelectedData());
			}
		}

		public virtual void StopSelection()
		{
			if(this.stopSchematicAsset != null)
			{
				Schematic.Play(this.stopSchematicAsset, this, null, this.user, this.user, false, null,
					this.CreateSelectedData());
			}

			this.user = null;
			this.action = null;
		}

		protected virtual SelectedDataHandler CreateSelectedData()
		{
			SelectedDataHandler handler = SelectedDataHelper.CreateSelectedData("action", this.action.Shortcut);
			handler.Change("cursor", this.gameObject, ListChangeType.Set);
			return handler;
		}
	}
}
