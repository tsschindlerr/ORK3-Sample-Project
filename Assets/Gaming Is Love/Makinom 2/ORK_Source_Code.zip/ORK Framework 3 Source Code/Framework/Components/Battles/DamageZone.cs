
using GamingIsLove.ORKFramework;
using UnityEngine;
using System.Collections.Generic;
using System;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Schematics;

namespace GamingIsLove.ORKFramework.Components
{
	public interface IDamageZone
	{
		Combatant Combatant
		{
			get;
			set;
		}

		bool CanDamage(DamageDealer dealer, BaseAction action);

		void Damage(BaseAction action);
	}

	[AddComponentMenu("ORK Framework/Battle/Damage Zone")]
	public class DamageZone : DamageBase, ISerializationCallbackReceiver, ISchematicStarter, IDamageZone
	{
		[System.NonSerialized]
		public Settings settings = new Settings();

		[SerializeField]
		[HideInInspector]
		protected ComponentDataFile serialize_setting;

		public virtual bool CanDamage(DamageDealer dealer, BaseAction action)
		{
			return action.CanTarget(this.Combatant) &&
				(!dealer.settings.alwaysOn ||
					!dealer.settings.alwaysOnConsumeCosts ||
					action.Shortcut.CanUse(action.User, false, true)) &&
				(!dealer.settings.oneTimeDamage ||
					!dealer.IsBlocked(this.Combatant)) &&
				(!dealer.settings.oneTarget ||
					dealer.BlockedCount == 0 ||
				(dealer.BlockedCount == 1 &&
					dealer.IsBlocked(this.Combatant))) &&
				(dealer.settings.damageEvery == 0 ||
					!dealer.IsDamageBlocked(this.Combatant));
		}

		public virtual void Damage(BaseAction action)
		{
			if(this.settings.playSound && this.settings.sound != null)
			{
				this.settings.sound.Play(this.combatant);
			}

			if(this.settings.blockDamage)
			{
				if(this.settings.showBlockFlyingText &&
					!this.combatant.Setting.blockFlyingTextsBlocking)
				{
					ORK.Access.Battle.ShowBlockFlyingText("", this.combatant,
						this.settings.flyingTextAtObject ? this.gameObject : null, action.Shortcut);
				}
			}
			else if(TargetHelper.CheckDeath(this.combatant, action.TargetDead))
			{
				List<Combatant> target = new List<Combatant>();
				target.Add(this.combatant);

				DamageDealerActivation ddActivation = action.GetDamageDealerActivation();
				if(ddActivation != null &&
					ddActivation.battleAnimation.Animate)
				{
					List<KeyValuePair<BattleAnimation, Schematic>> schematics = new List<KeyValuePair<BattleAnimation, Schematic>>();
					ddActivation.battleAnimation.GetBattleAnimation(action.User, ref schematics);
					new DamageDealerAction(action, target,
						this.settings.flyingTextAtObject ? this.gameObject : null,
						schematics, this.settings.damageFactor).PerformAction();
				}
				else
				{
					action.Calculate(target, this.settings.damageFactor, null,
						this.settings.flyingTextAtObject ? this.gameObject : null, null);
				}
			}

			if(this.settings.schematicAsset.StoredAsset != null)
			{
				Schematic.Play(this.settings.schematicAsset.StoredAsset, this, this,
					action.User != null ? (object)action.User : this.gameObject, this.Combatant);
			}
		}

		public virtual void SchematicFinished(Schematic schematic)
		{

		}


		/*
		============================================================================
		Gizmo functions
		============================================================================
		*/
		protected virtual void OnDrawGizmos()
		{
			Gizmos.DrawIcon(this.transform.position, "/GamingIsLove/ORKFramework/Components/DamageZone Icon.png");
		}


		/*
		============================================================================
		Serialization functions
		============================================================================
		*/
		public virtual void OnBeforeSerialize()
		{
			this.serialize_setting = this.settings.GetData().GetComponentDataFile("settings", false);
		}

		public virtual void OnAfterDeserialize()
		{
			if(this.serialize_setting != null)
			{
				this.settings.SetData(this.serialize_setting.ToDataObject());
				this.serialize_setting = null;
			}
		}


		/*
		============================================================================
		Settings class
		============================================================================
		*/
		public class Settings : BaseData
		{
			// block settings
			[EditorHelp("Block Damage", "This damage zone blocks damage.")]
			[EditorFoldout("Damage Zone Settings", "Define if and how the damage zone can receive damage.")]
			[EditorLabel("This damage zone must be placed on a combatant.\n" +
				"The combatant will receive damage when being hit by a damage dealer (based on the damage dealer's 'Start Type').")]
			public bool blockDamage = false;

			[EditorHelp("Show Flying Text", "Show the block flying text.")]
			[EditorIndent]
			[EditorCondition("blockDamage", true)]
			public bool showBlockFlyingText = false;

			[EditorHelp("Damage Factor", "The damage factor used to multiply the damage on this damage zone.")]
			[EditorElseCondition]
			[EditorEndCondition]
			public float damageFactor = 1.0f;

			[EditorHelp("Flying Text At Object", "Flying texts from damage to this damage zone will use " +
				"this game object instead of the combatant's game object for positioning.")]
			public bool flyingTextAtObject = false;


			// schematic settings
			[EditorHelp("Schematic Asset", "Use a schematic asset when this damage zone is hit.")]
			[EditorEndFoldout]
			[EditorSeparator]
			public AssetSource<MakinomSchematicAsset> schematicAsset = new AssetSource<MakinomSchematicAsset>();


			// sound settings
			[EditorHelp("Play Sound", "Play a sound when this damage zone is hit.")]
			[EditorFoldout("Audio Settings", "Optionally play a sound when this damage zone is hit.")]
			public bool playSound = false;

			[EditorEndFoldout]
			[EditorCondition("playSound", true)]
			[EditorEndCondition]
			[EditorAutoInit]
			public PlayAudioCombatant sound;

			public Settings()
			{

			}
		}
	}
}
