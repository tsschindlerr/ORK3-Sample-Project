
using UnityEngine;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class CraftingRecipesSettings : GenericAssetListSettings<CraftingRecipeAsset, CraftingRecipe>
	{
		public CraftingRecipesSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
			this.CreateGUIDLookup();
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "Crafting Recipes"; }
		}
	}
}
