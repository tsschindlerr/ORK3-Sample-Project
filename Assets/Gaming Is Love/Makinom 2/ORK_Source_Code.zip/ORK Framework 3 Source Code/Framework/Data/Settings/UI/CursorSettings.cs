﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.UI;

namespace GamingIsLove.ORKFramework
{
	public class CursorSettings : BaseSettings
	{
		// default cursor
		[EditorHelp("Reset to System Default", "Reset to the system default cursor when no default cursor is found.")]
		[EditorFoldout("Default Cursor", "The default cursor is used whenever no other cursor is being used.\n" +
			"If no cursor texture is selected, the system cursor is used.", "")]
		public bool resetSystemDefault = true;

		[EditorEndFoldout]
		public CursorChange defaultCursor = new CursorChange();


		// valid target cursors
		[EditorHelp("Over Origin Box", "The 'Valid' cursors will also be displayed when " +
			"hovering over the origin UI box that started the target selection " +
			"(e.g. a 'Combatant' HUD with a 'Shortcut' element starting the target selection through 'Click Use').", "")]
		[EditorFoldout("Target Selection Cursors (Valid)", "The target selection cursors are used during target selection.\n" +
			"The 'Valid' cursors are used when hovering over a valid target.", "")]
		public bool targetValidOriginBox = false;

		[EditorHelp("Over Origin Shortcut", "The 'Valid' cursors will also be displayed when hovering over the shortcut slot " +
			"that started the target selection (e.g. using a shortcut slot through 'Click Use' in a HUD or a control map key).", "")]
		[EditorCondition("targetValidOriginBox", false)]
		[EditorEndCondition]
		[EditorDefaultValue(false)]
		public bool targetValidOriginShortcut = false;

		[EditorFoldout("Target Self Cursor", "The target self cursor is used when hovering over a valid target for 'Self' targeting actions.\n" +
			"If no cursor texture is selected, the default cursor is used.", "")]
		[EditorEndFoldout]
		public CursorChange targetSelfValid = new CursorChange();

		[EditorFoldout("Target Ally Cursor", "The target ally cursor is used when hovering over a valid target for 'Ally' targeting actions.\n" +
			"If no cursor texture is selected, the default cursor is used.", "")]
		[EditorEndFoldout]
		public CursorChange targetAllyValid = new CursorChange();

		[EditorFoldout("Target Enemy Cursor", "The target enemy cursor is used when hovering over a valid target for 'Enemy' targeting actions.\n" +
			"If no cursor texture is selected, the default cursor is used.", "")]
		[EditorEndFoldout]
		public CursorChange targetEnemyValid = new CursorChange();

		[EditorFoldout("Target All Cursor", "The target all cursor is used when hovering over a valid target for 'All' targeting actions.\n" +
			"If no cursor texture is selected, the default cursor is used.", "")]
		[EditorEndFoldout(2)]
		public CursorChange targetAllValid = new CursorChange();


		// invalid target cursors
		[EditorFoldout("Target Selection Cursors (Invalid)", "The target selection cursors are used during target selection.\n" +
			"The 'Invalid' cursors are used when hovering over an invalid target.", "",
			"Target Self Cursor", "The target self cursor is used when hovering over an invalid target for 'Self' targeting actions.\n" +
			"If no cursor texture is selected, the default cursor is used.", "")]
		[EditorEndFoldout]
		public CursorChange targetSelfInvalid = new CursorChange();

		[EditorFoldout("Target Ally Cursor", "The target ally cursor is used when hovering over an invalid target for 'Ally' targeting actions.\n" +
			"If no cursor texture is selected, the default cursor is used.", "")]
		[EditorEndFoldout]
		public CursorChange targetAllyInvalid = new CursorChange();

		[EditorFoldout("Target Enemy Cursor", "The target enemy cursor is used when hovering over an invalid target for 'Enemy' targeting actions.\n" +
			"If no cursor texture is selected, the default cursor is used.", "")]
		[EditorEndFoldout]
		public CursorChange targetEnemyInvalid = new CursorChange();

		[EditorFoldout("Target All Cursor", "The target all cursor is used when hovering over an invalid target for 'All' targeting actions.\n" +
			"If no cursor texture is selected, the default cursor is used.", "")]
		[EditorEndFoldout(2)]
		public CursorChange targetAllInvalid = new CursorChange();


		// none target cursors
		[EditorFoldout("Target Selection Cursors (None)", "The target selection cursors are used during target selection.\n" +
			"The 'None' cursors are used when not hovering over any target.", "",
			"Target Self Cursor", "The target self cursor is used when not hovering over any target for 'Self' targeting actions.\n" +
			"If no cursor texture is selected, the default cursor is used.", "")]
		[EditorEndFoldout]
		public CursorChange targetSelfNone = new CursorChange();

		[EditorFoldout("Target Ally Cursor", "The target ally cursor is used when not hovering over any target for 'Ally' targeting actions.\n" +
			"If no cursor texture is selected, the default cursor is used.", "")]
		[EditorEndFoldout]
		public CursorChange targetAllyNone = new CursorChange();

		[EditorFoldout("Target Enemy Cursor", "The target enemy cursor is used when not hovering over any target for 'Enemy' targeting actions.\n" +
			"If no cursor texture is selected, the default cursor is used.", "")]
		[EditorEndFoldout]
		public CursorChange targetEnemyNone = new CursorChange();

		[EditorFoldout("Target All Cursor", "The target all cursor is used when not hovering over any target for 'All' targeting actions.\n" +
			"If no cursor texture is selected, the default cursor is used.", "")]
		[EditorEndFoldout(2)]
		public CursorChange targetAllNone = new CursorChange();


		// in action cursors
		[EditorHelp("Ignore Death", "Death actions don't use in action cursors.", "")]
		[EditorFoldout("In Action Cursors", "The in action cursors are used while a combatant is in action.", "")]
		public bool inActionIgnoreDeath = false;

		[EditorFoldout("Player In Action Cursor", "The player in action cursor is used when a player controlled combatant is in action.\n" +
			"If no cursor texture is selected, the default cursor is used.", "")]
		[EditorEndFoldout]
		public CursorChange inActionPlayer = new CursorChange();

		[EditorFoldout("Ally In Action Cursor", "The ally in action cursor is used when an ally of the player is in action.\n" +
			"If no cursor texture is selected, the default cursor is used.", "")]
		[EditorEndFoldout]
		public CursorChange inActionAlly = new CursorChange();

		[EditorFoldout("Enemy In Action Cursor", "The enemy in action cursor is used when an enemy of the player is in action.\n" +
			"If no cursor texture is selected, the default cursor is used.", "")]
		[EditorEndFoldout(2)]
		public CursorChange inActionEnemy = new CursorChange();


		// attack range cursors
		[EditorHelp("Show Attack Range", "The attack range cursors will be displayed.\n" +
			"If disabled, the attack range cursors will not be displayed.", "")]
		[EditorFoldout("Attack Range Cursors", "The attack range cursors are used while a player controlled combatant " +
			"selects battle actions (not during target selection).\n" +
			"The cursor indicates if valid targets are within use range of the combatant's base attack or not.", "")]
		public bool showAttackRangeCursor = false;

		[EditorHelp("Cursor Over", "Only show the attack range cursor while hovering the cursor over a valid target.", "")]
		[EditorCondition("showAttackRangeCursor", true)]
		public bool attackRangeCursorOver = false;

		[EditorFoldout("In Range Cursor", "The in range cursor is used when valid targets are within use range of the combatant's base attack.\n" +
			"If no cursor texture is selected, the default cursor is used.", "")]
		[EditorEndFoldout]
		public CursorChange inAttackRange = new CursorChange();

		[EditorFoldout("Out Of Range Cursor", "The out of range cursor is used when no valid targets are within use range of the combatant's base attack.\n" +
			"If no cursor texture is selected, the default cursor is used.", "")]
		[EditorEndFoldout(2)]
		[EditorEndCondition]
		public CursorChange outOfAttackRange = new CursorChange();


		// grid battle cursors
		// placement
		[EditorFoldout("Grid Battle Cursors", "The grid battle cursors are used during grid cell selections.", "",
			"Placement Cursors", "The placement cursors are used while the player places combatants on the grid.", "",
			"Placement Selection Cursor", "The placement selection cursor is used when a valid grid cell to place on is selected.\n" +
			"If no cursor texture is selected, the default cursor is used.", "")]
		[EditorEndFoldout]
		public CursorChange gridPlacementSelection = new CursorChange();

		[EditorFoldout("No Placement Selection Cursor", "The no placement selection cursor is used when no valid grid cell to place on is selected.\n" +
			"If no cursor texture is selected, the default cursor is used.", "")]
		[EditorEndFoldout(2)]
		public CursorChange gridNoPlacementSelection = new CursorChange();

		// orientation
		[EditorFoldout("Orientation Selection Cursor", "The orientation selection cursor is used during the grid orientation selection.\n" +
			"If no cursor texture is selected, the default cursor is used.", "")]
		[EditorEndFoldout]
		public CursorChange gridOrientationSelection = new CursorChange();

		// move command
		[EditorFoldout("Move Command Cursors", "The move command cursors are used while a player controlled combatant " +
			"selects a grid cell to move to.\n" +
			"The cursor indicates if valid cell is selected or not.", "",
			"Move Selection Cursor", "The move selection cursor is used when a valid grid cell to move to is selected.\n" +
			"If no cursor texture is selected, the default cursor is used.", "")]
		[EditorEndFoldout]
		public CursorChange gridMoveSelection = new CursorChange();

		[EditorFoldout("No Move Selection Cursor", "The no move selection cursor is used when no valid grid cell to move to is selected.\n" +
			"If no cursor texture is selected, the default cursor is used.", "")]
		[EditorEndFoldout(2)]
		public CursorChange gridNoMoveSelection = new CursorChange();

		// examine
		[EditorFoldout("Examine Cursors", "The examine cursors are used while a player is examining the grid.", "",
			"Examine Selection Cursor", "The examine selection cursor is used when examining an unblocked grid cell.\n" +
			"If no cursor texture is selected, the default cursor is used.", "")]
		[EditorEndFoldout]
		public CursorChange gridExamineSelection = new CursorChange();

		[EditorFoldout("Examine Blocked Selection Cursor", "The examine blocked selection cursor is used when examining a blocked grid cell.\n" +
			"If no cursor texture is selected, the default cursor is used.", "")]
		[EditorEndFoldout(3)]
		public CursorChange gridExamineSelectionBlocked = new CursorChange();


		// in-game
		protected List<CursorType> currentCursor = new List<CursorType>();

		protected List<CursorChange> customCursors = new List<CursorChange>();

		protected CursorTypeSorter sorter = new CursorTypeSorter();


		// attack range cursor
		protected List<Combatant> attackRangeCombatants = new List<Combatant>();

		protected bool isInAttackRange = false;

		public CursorSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "Cursor Settings"; }
		}


		/*
		============================================================================
		Cursor functions
		============================================================================
		*/
		public virtual bool ShowCursor(CursorType type)
		{
			if(!this.currentCursor.Contains(type))
			{
				if(CursorType.Default == type)
				{
					this.currentCursor.Clear();
					this.customCursors.Clear();
				}
				else
				{
					if(this.IsTargetSelection(type))
					{
						this.DoRemoveTargetSelection();
					}

					this.currentCursor.Add(type);
					this.currentCursor.Sort(this.sorter);
				}

				return this.ShowCurrentCursor();
			}
			return true;
		}

		public virtual void RemoveCursor(CursorType type)
		{
			if(this.currentCursor.Contains(type))
			{
				for(int i = this.currentCursor.Count - 1; i >= 0; i--)
				{
					if(this.currentCursor[i] == type)
					{
						this.currentCursor.RemoveAt(i);
						break;
					}
				}

				this.ShowCurrentCursor();
			}
		}

		protected virtual bool ShowCurrentCursor()
		{
			return this.DoShowCursor(this.currentCursor.Count > 0 ?
				this.currentCursor[this.currentCursor.Count - 1] :
				CursorType.Default);
		}


		/*
		============================================================================
		Show functions
		============================================================================
		*/
		protected virtual bool DoShowCursor(CursorType type)
		{
			// default
			if(CursorType.Default == type)
			{
				return this.ShowFallbackReset(this.defaultCursor);
			}
			// valid target
			else if(CursorType.TargetSelfValid == type)
			{
				return this.ShowFallbackDefault(this.targetSelfValid);
			}
			else if(CursorType.TargetAllyValid == type)
			{
				return this.ShowFallbackDefault(this.targetAllyValid);
			}
			else if(CursorType.TargetEnemyValid == type)
			{
				return this.ShowFallbackDefault(this.targetEnemyValid);
			}
			else if(CursorType.TargetAllValid == type)
			{
				return this.ShowFallbackDefault(this.targetAllValid);
			}
			// invalid target
			else if(CursorType.TargetSelfInvalid == type)
			{
				return this.ShowFallbackDefault(this.targetSelfInvalid);
			}
			else if(CursorType.TargetAllyInvalid == type)
			{
				return this.ShowFallbackDefault(this.targetAllyInvalid);
			}
			else if(CursorType.TargetEnemyInvalid == type)
			{
				return this.ShowFallbackDefault(this.targetEnemyInvalid);
			}
			else if(CursorType.TargetAllInvalid == type)
			{
				return this.ShowFallbackDefault(this.targetAllInvalid);
			}
			// none target
			else if(CursorType.TargetSelfNone == type)
			{
				return this.ShowFallbackDefault(this.targetSelfNone);
			}
			else if(CursorType.TargetAllyNone == type)
			{
				return this.ShowFallbackDefault(this.targetAllyNone);
			}
			else if(CursorType.TargetEnemyNone == type)
			{
				return this.ShowFallbackDefault(this.targetEnemyNone);
			}
			else if(CursorType.TargetAllNone == type)
			{
				return this.ShowFallbackDefault(this.targetAllNone);
			}
			// in action
			else if(CursorType.InActionPlayer == type)
			{
				return this.ShowFallbackDefault(this.inActionPlayer);
			}
			else if(CursorType.InActionAlly == type)
			{
				return this.ShowFallbackDefault(this.inActionAlly);
			}
			else if(CursorType.InActionEnemy == type)
			{
				return this.ShowFallbackDefault(this.inActionEnemy);
			}
			// attack range cursors
			else if(CursorType.AttackRange == type)
			{
				if(this.showAttackRangeCursor)
				{
					return this.ShowFallbackDefault(this.isInAttackRange ?
							this.inAttackRange : this.outOfAttackRange);
				}
			}
			// grid
			// placement
			else if(CursorType.GridPlacementSelection == type)
			{
				return this.ShowFallbackDefault(this.gridPlacementSelection);
			}
			else if(CursorType.GridNoPlacementSelection == type)
			{
				return this.ShowFallbackDefault(this.gridNoPlacementSelection);
			}
			// orientation
			else if(CursorType.GridOrientationSelection == type)
			{
				return this.ShowFallbackDefault(this.gridOrientationSelection);
			}
			// move command
			else if(CursorType.GridMoveSelection == type)
			{
				return this.ShowFallbackDefault(this.gridMoveSelection);
			}
			else if(CursorType.GridNoMoveSelection == type)
			{
				return this.ShowFallbackDefault(this.gridNoMoveSelection);
			}
			// examine
			else if(CursorType.GridExamineSelection == type)
			{
				return this.ShowFallbackDefault(this.gridExamineSelection);
			}
			else if(CursorType.GridExamineSelectionBlocked == type)
			{
				return this.ShowFallbackDefault(this.gridExamineSelectionBlocked);
			}
			// custom
			else if(CursorType.Custom == type)
			{
				if(this.customCursors.Count > 0)
				{
					return this.ShowFallbackDefault(this.customCursors[this.customCursors.Count - 1]);
				}
			}
			return false;
		}

		protected virtual void Reset()
		{
			if(this.resetSystemDefault)
			{
				Cursor.SetCursor(null, Vector2.zero, CursorMode.Auto);
			}
		}

		protected virtual void ShowDefaultCursor()
		{
			if(!this.defaultCursor.SetCursor())
			{
				this.Reset();
			}
		}
		protected virtual bool ShowFallbackReset(CursorChange cursor)
		{
			if(cursor.SetCursor())
			{
				return true;
			}
			else
			{
				this.Reset();
				return false;
			}
		}

		protected virtual bool ShowFallbackDefault(CursorChange cursor)
		{
			if(cursor.SetCursor())
			{
				return true;
			}
			else
			{
				this.ShowDefaultCursor();
				return false;
			}
		}


		/*
		============================================================================
		Target selection functions
		============================================================================
		*/
		protected virtual bool IsTargetSelection(CursorType type)
		{
			return CursorType.TargetSelfValid == type ||
				CursorType.TargetAllyValid == type ||
				CursorType.TargetEnemyValid == type ||
				CursorType.TargetAllValid == type ||
				CursorType.TargetSelfInvalid == type ||
				CursorType.TargetAllyInvalid == type ||
				CursorType.TargetEnemyInvalid == type ||
				CursorType.TargetAllInvalid == type ||
				CursorType.TargetSelfNone == type ||
				CursorType.TargetAllyNone == type ||
				CursorType.TargetEnemyNone == type ||
				CursorType.TargetAllNone == type;
		}

		public virtual bool ShowTargetValid(TargetSelectionSettings targetSettings)
		{
			if(targetSettings != null)
			{
				if(targetSettings.TargetSelf())
				{
					return this.ShowCursor(CursorType.TargetSelfValid);
				}
				else if(targetSettings.TargetAlly())
				{
					return this.ShowCursor(CursorType.TargetAllyValid);
				}
				else if(targetSettings.TargetEnemy())
				{
					return this.ShowCursor(CursorType.TargetEnemyValid);
				}
				else if(targetSettings.TargetAll())
				{
					return this.ShowCursor(CursorType.TargetAllValid);
				}
			}
			return false;
		}

		public virtual bool ShowTargetInvalid(TargetSelectionSettings targetSettings)
		{
			if(targetSettings != null)
			{
				if(targetSettings.TargetSelf())
				{
					return this.ShowCursor(CursorType.TargetSelfInvalid);
				}
				else if(targetSettings.TargetAlly())
				{
					return this.ShowCursor(CursorType.TargetAllyInvalid);
				}
				else if(targetSettings.TargetEnemy())
				{
					return this.ShowCursor(CursorType.TargetEnemyInvalid);
				}
				else if(targetSettings.TargetAll())
				{
					return this.ShowCursor(CursorType.TargetAllInvalid);
				}
			}
			return false;
		}

		public virtual bool ShowTargetNone(TargetSelectionSettings targetSettings)
		{
			if(targetSettings != null)
			{
				if(targetSettings.TargetSelf())
				{
					return this.ShowCursor(CursorType.TargetSelfNone);
				}
				else if(targetSettings.TargetAlly())
				{
					return this.ShowCursor(CursorType.TargetAllyNone);
				}
				else if(targetSettings.TargetEnemy())
				{
					return this.ShowCursor(CursorType.TargetEnemyNone);
				}
				else if(targetSettings.TargetAll())
				{
					return this.ShowCursor(CursorType.TargetAllNone);
				}
			}
			return false;
		}

		public virtual bool ShowTargetOverBox(Combatant user, IShortcut shortcut)
		{
			IUIBase overUI = Maki.UI.CursorOverBox;
			if(overUI != null)
			{
				if(user != null &&
					((ORK.Control.Cursor.targetValidOriginBox &&
						user.Battle.BattleMenu != null &&
						user.Battle.BattleMenu.targetOriginUI != null &&
						user.Battle.BattleMenu.targetOriginUI == overUI) ||
					(ORK.Control.Cursor.targetValidOriginShortcut &&
						shortcut == ORKComponentHelper.ToShortcut(overUI.CursorOverTooltip))))
				{
					return this.ShowTargetValid(TargetSelectionSettings.Get(shortcut));
				}
				else
				{
					this.RemoveTargetSelection();
					return true;
				}
			}
			return false;
		}

		public virtual void RemoveTargetSelection()
		{
			this.DoRemoveTargetSelection();
			this.ShowCurrentCursor();
		}

		protected virtual void DoRemoveTargetSelection()
		{
			for(int i = this.currentCursor.Count - 1; i >= 0; i--)
			{
				if(this.IsTargetSelection(this.currentCursor[i]))
				{
					this.currentCursor.RemoveAt(i);
				}
			}
		}


		/*
		============================================================================
		In action functions
		============================================================================
		*/
		protected virtual bool CheckAction(BaseAction action)
		{
			return action != null && action.User != null &&
				(!this.inActionIgnoreDeath || !action.IsType(ActionType.Death));
		}

		public virtual bool ShowInAction(BaseAction action)
		{
			if(this.CheckAction(action))
			{
				if(CombatantAffiliationType.Player == action.ActionAffiliation)
				{
					return this.ShowCursor(CursorType.InActionPlayer);
				}
				else if(CombatantAffiliationType.Ally == action.ActionAffiliation)
				{
					return this.ShowCursor(CursorType.InActionAlly);
				}
				else if(CombatantAffiliationType.Enemy == action.ActionAffiliation)
				{
					return this.ShowCursor(CursorType.InActionEnemy);
				}
			}
			return false;
		}

		public virtual void RemoveInAction(BaseAction action)
		{
			if(this.CheckAction(action))
			{
				if(CombatantAffiliationType.Player == action.ActionAffiliation)
				{
					this.RemoveCursor(CursorType.InActionPlayer);
				}
				else if(CombatantAffiliationType.Ally == action.ActionAffiliation)
				{
					this.RemoveCursor(CursorType.InActionAlly);
				}
				else if(CombatantAffiliationType.Enemy == action.ActionAffiliation)
				{
					this.RemoveCursor(CursorType.InActionEnemy);
				}
			}
		}


		/*
		============================================================================
		Attack range cursor functions
		============================================================================
		*/
		public virtual bool ShowAttackRange(Combatant combatant)
		{
			if(this.showAttackRangeCursor &&
				!this.attackRangeCursorOver &&
				combatant != null &&
				!combatant.IsAIControlled() &&
				combatant.IsPlayerControlled())
			{
				if(this.attackRangeCombatants.Contains(combatant))
				{
					this.RemoveCursor(CursorType.AttackRange);
				}
				else
				{
					this.attackRangeCombatants.Add(combatant);
				}

				return this.DoShowAttackRange(combatant);
			}
			return false;
		}

		public virtual void RemoveAttackRange(Combatant combatant)
		{
			if(this.showAttackRangeCursor &&
				!this.attackRangeCursorOver &&
				combatant != null)
			{
				if(this.attackRangeCombatants.Contains(combatant))
				{
					this.attackRangeCombatants.Remove(combatant);
					this.RemoveCursor(CursorType.AttackRange);
					if(this.attackRangeCombatants.Count > 0)
					{
						this.DoShowAttackRange(this.attackRangeCombatants[this.attackRangeCombatants.Count - 1]);
					}
				}
			}
		}

		protected virtual bool DoShowAttackRange(Combatant combatant)
		{
			if(combatant != null)
			{
				AbilityShortcut ability = combatant.Abilities.GetCurrentBaseAttack();
				this.isInAttackRange = ability != null &&
					ability.CanUse(combatant, !ability.IsCounterAttack, true) &&
					(ability.IsNoneTarget() || ability.HasPossibleTargets(combatant, null));
				return this.ShowCursor(CursorType.AttackRange);
			}
			return false;
		}

		public virtual bool ShowAttackRangeCursorOver(Combatant combatant, Combatant target)
		{
			if(this.showAttackRangeCursor &&
				this.attackRangeCursorOver &&
				combatant != null &&
				target != null &&
				!combatant.IsAIControlled() &&
				combatant.IsPlayerControlled())
			{
				if(this.attackRangeCombatants.Count > 0)
				{
					this.attackRangeCombatants.Clear();
				}
				this.attackRangeCombatants.Add(combatant);

				this.RemoveCursor(CursorType.AttackRange);
				AbilityShortcut ability = combatant.Abilities.GetCurrentBaseAttack();
				if(ability != null &&
					ability.CanTarget(combatant, target))
				{
					this.isInAttackRange = ability.CanUse(combatant, !ability.IsCounterAttack, true) &&
						(ability.IsNoneTarget() || ability.InRange(combatant, target));
					return this.ShowCursor(CursorType.AttackRange);
				}
			}
			return false;
		}

		public virtual void RemoveAttackRangeCursorOver(Combatant combatant)
		{
			if(this.showAttackRangeCursor &&
				this.attackRangeCursorOver &&
				this.attackRangeCombatants.Contains(combatant))
			{
				this.attackRangeCombatants.Clear();
				this.RemoveCursor(CursorType.AttackRange);
			}
		}


		/*
		============================================================================
		Grid functions
		============================================================================
		*/
		public virtual void ShowGridPlacementSelection()
		{
			this.RemoveCursor(CursorType.GridNoPlacementSelection);
			this.ShowCursor(CursorType.GridPlacementSelection);
		}

		public virtual void ShowGridNoPlacementSelection()
		{
			this.RemoveCursor(CursorType.GridPlacementSelection);
			this.ShowCursor(CursorType.GridNoPlacementSelection);
		}

		public virtual void RemoveGridPlacementSelections()
		{
			this.RemoveCursor(CursorType.GridNoPlacementSelection);
			this.RemoveCursor(CursorType.GridPlacementSelection);
		}

		public virtual void ShowGridMoveSelection()
		{
			this.RemoveCursor(CursorType.GridNoMoveSelection);
			this.ShowCursor(CursorType.GridMoveSelection);
		}

		public virtual void ShowGridNoMoveSelection()
		{
			this.RemoveCursor(CursorType.GridMoveSelection);
			this.ShowCursor(CursorType.GridNoMoveSelection);
		}

		public virtual void RemoveGridMoveSelections()
		{
			this.RemoveCursor(CursorType.GridNoMoveSelection);
			this.RemoveCursor(CursorType.GridMoveSelection);
		}

		public virtual void ShowGridExamineSelection()
		{
			this.RemoveCursor(CursorType.GridExamineSelectionBlocked);
			this.ShowCursor(CursorType.GridExamineSelection);
		}

		public virtual void ShowGridExamineSelectionBlocked()
		{
			this.RemoveCursor(CursorType.GridExamineSelection);
			this.ShowCursor(CursorType.GridExamineSelectionBlocked);
		}

		public virtual void RemoveGridExamineSelections()
		{
			this.RemoveCursor(CursorType.GridExamineSelectionBlocked);
			this.RemoveCursor(CursorType.GridExamineSelection);
		}


		/*
		============================================================================
		Custom cursor functions
		============================================================================
		*/
		public virtual bool ShowCustomCursor(CursorChange cursor)
		{
			if(!this.customCursors.Contains(cursor))
			{
				this.currentCursor.Add(CursorType.Custom);
				this.currentCursor.Sort(this.sorter);
				this.customCursors.Add(cursor);

				this.ShowCurrentCursor();
				return true;
			}
			return false;
		}

		public virtual void RemoveCustomCursor(CursorChange cursor)
		{
			if(this.customCursors.Contains(cursor))
			{
				this.customCursors.Remove(cursor);
				for(int i = this.currentCursor.Count - 1; i >= 0; i--)
				{
					if(this.currentCursor[i] == CursorType.Custom)
					{
						this.currentCursor.RemoveAt(i);
						break;
					}
				}

				this.ShowCurrentCursor();
			}
		}
	}
}
