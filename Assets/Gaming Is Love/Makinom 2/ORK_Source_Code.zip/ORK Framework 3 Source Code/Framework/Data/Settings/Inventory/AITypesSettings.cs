﻿
using UnityEngine;
using GamingIsLove.ORKFramework.AI;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class AITypesSettings : GenericAssetListSettings<AITypeAsset, AIType>
	{
		public AITypesSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
			this.CreateGUIDLookup();
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "AI Types"; }
		}
	}
}
