
using UnityEngine;
using GamingIsLove.Makinom.UI;

namespace GamingIsLove.Makinom
{
	public enum UIBoxAutoScrollType { Enable, Disable, OnIndexChange }

	public class UIBoxesSettings : BaseSettings, IUISystemChanged
	{
		// general settings
		// cursor timeout
		[EditorHelp("Cursor Timeout (s)", "The time in seconds that has to pass between 2 cursor moves (e.g. input selection).")]
		[EditorFoldout("General Settings", "General settings for all UI boxes.", "")]
		public float cursorTimeout = 0.25f;

		[EditorHelp("Cursor Hold Timeout (s)", "The time in seconds that has to pass between consecutive cursor moves " +
			"when the input is received without a break (e.g. holding a key).")]
		public float cursorHoldTimeout = 0.25f;

		// accept timeout
		[EditorHelp("Use Accept Timeout", "Use a timeout between allowing 2 accepts.\n" +
			"This is for all types of accepting, i.e. via 'Accept Key' and 'Accept Click' on inputs.")]
		[EditorSeparator]
		public bool useAcceptTimeout = false;

		[EditorHelp("Accept Timeout (s)", "The time in seconds between allowing 2 accepts.")]
		[EditorIndent]
		[EditorCondition("useAcceptTimeout", true)]
		[EditorEndCondition]
		public float acceptTimeout = 0.2f;

		// scroll settings
		[EditorHelp("Key Scroll Speed", "The amount of pixels the scrollbar is moved when using keys.")]
		[EditorSeparator]
		[EditorTitleLabel("Scroll Settings")]
		public float scrollSpeed = 3;

		[EditorHelp("Auto Scroll Type", "Select how scrolling is handled when the selected input changed:\n" +
			"- Enable: Automatically scroll each time the selected input is set (including setting to the same input, e.g. when the content is updated).\n" +
			"- Disable: Changing the selected input never changes the scrolling.\n" +
			"- On Index Change: Only scroll to the selected input when the selected index is changed. E.g. setting to the same input during content updates will not update scrolling.")]
		public UIBoxAutoScrollType autoScrollType = UIBoxAutoScrollType.Enable;

		// tooltip
		[EditorHelp("Selection Tooltip", "Tooltips are displayed for the currently selected input of the focused UI box.\n" +
			"Cursor over always takes priority.\n" +
			"If disabled, only hovering the cursor over content with a tooltip will display a tooltip.")]
		[EditorSeparator]
		[EditorTitleLabel("Tooltip Settings")]
		public bool selectionTooltip = false;

		// focus click
		[EditorHelp("Focus Cursor Over", "Focus will be on the UI box the mouse cursor is currently over.")]
		[EditorSeparator]
		[EditorTitleLabel("Focus Settings")]
		public bool focusCursorOver = false;

		[EditorHelp("Focus Left Click", "Clicking with the left mouse button on a UI box will change focus to it.")]
		public bool focusLeftClick = true;

		[EditorHelp("Focus Middle Click", "Clicking with the middle mouse button on a UI box will change focus to it.")]
		public bool focusMiddleClick = false;

		[EditorHelp("Focus Right Click", "Clicking with the right mouse button on a UI box will change focus to it.")]
		public bool focusRightClick = false;

		// cursor over
		[EditorHelp("Cursor Over Selection", "Hovering the cursor above an input will select it (not accept).\n" +
			"This only happens on the currently focused UI box.")]
		[EditorSeparator]
		[EditorTitleLabel("Cursor Over Settings")]
		public bool inputCursorOverSelection = false;

		[EditorHelp("Unlocked Cursor Over", "The cursor over selection is only used when the cursor isn't locked.")]
		[EditorCondition("inputCursorOverSelection", true)]
		public bool inputCursorOverUnlocked = true;

		[EditorHelp("Unfocused Cursor Over", "The cursor over selection is also used on onfocused UI boxes.\n" +
			"If disabled, only the currently focused UI box will use cursor over selection.")]
		[EditorEndFoldout]
		[EditorEndCondition]
		public bool inputCursorOverUnfocused = true;


		// default controls
		[EditorFoldout("Default Controls", "The default controls for all UI boxes.\n" +
			"This settings can be overridden by each UI box individually.", "")]
		[EditorEndFoldout]
		public MenuControls controls = new MenuControls();


		// default audio
		[EditorFoldout("Default Audio Settings", "The audio clips played when interacting with menus or dialogues (e.g. cursor move, accept).\n" +
			"You can set the volume of every clip.\n" +
			"This settings can be overridden by each UI box individually.", "")]
		[EditorEndFoldout]
		public MenuAudioClips audio = new MenuAudioClips();


		// default ok/cancel buttons
		[EditorFoldout("Default Ok/Cancel Content", "Define the default content for 'Ok' and 'Cancel' buttons.\n" +
			"These settings can be overridden by each UI box individually.", "",
			"Ok Button Content", "Define the content of the 'Ok' buttons of UI boxes.\n" +
			"This setting can be overridden for each UI box individually.", "")]
		[EditorEndFoldout]
		[EditorLanguageExport("OkButton")]
		public ContentInput okButtonContent = new ContentInput("Ok");

		[EditorFoldout("Cancel Button Content", "Define the content of the 'Cancel' buttons of UI boxes.\n" +
			"This setting can be overridden for each UI box individually.", "")]
		[EditorEndFoldout(2)]
		[EditorLanguageExport("CancelButton")]
		public ContentInput cancelButtonContent = new ContentInput("Cancel");


		// default tab buttons
		[EditorFoldout("Default Tab Button Content", "Define the default content for previous and next tab buttons.\n" +
			"These settings can be overridden by each UI box individually.", "",
			"Previous Tab Button Content", "Define the content of the previous tab buttons of UI boxes.\n" +
			"This setting can be overridden for each UI box individually.", "")]
		[EditorEndFoldout]
		[EditorLanguageExport("PreviousTabButton")]
		public ContentInput previousTabButtonContent = new ContentInput("<");

		[EditorFoldout("Next Tab Button Content", "Define the content of the next tab buttons of UI boxes.\n" +
			"This setting can be overridden for each UI box individually.", "")]
		[EditorEndFoldout(2)]
		[EditorLanguageExport("NextTabButton")]
		public ContentInput nextTabButtonContent = new ContentInput(">");


		// default inactive colors
		[EditorFoldout("Default Inactive Colors", "UI boxes that aren't focused can be tinted to give the user a better visual feedback of which box is controlled.\n" +
			"This is only used for focusable (controlable) UI boxes, e.g. HUDs won't be tinted.\n" +
			"This setting can be overridden by each UI box individually.", "")]
		[EditorEndFoldout]
		public InactiveColor inactive = new InactiveColor();


		// typewriter
		[EditorFoldout("Default Typewriter", "UI boxes can display the content text letter by letter, creating a typewriter effect.\n" +
			"This setting can be overridden by each UI box individually.", "")]
		[EditorEndFoldout]
		public TypewriterSettings typewriter = new TypewriterSettings();


		// schematics
		[EditorFoldout("Default Schematics", "UI boxes can start schematics upon certain UI actions (e.g. opening, getting focus, selecting an input).\n" +
			"This setting can be overridden by each UI box individually.")]
		[EditorEndFoldout]
		public UIBoxSchematics schematics = new UIBoxSchematics();


		// UI system dependent
		public BaseDefaultUIBoxSettings defaultSettings = Maki.UISystem.settings.Create<BaseDefaultUIBoxSettings>();

		public UIBoxesSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			this.CheckUIData();
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "UI Boxes"; }
		}

		public override bool HasGeneralSettings
		{
			get { return true; }
		}


		/*
		============================================================================
		UI system changed
		============================================================================
		*/
		public virtual void CheckUIData()
		{
			if(!Maki.UISystem.settings.CheckType<BaseDefaultUIBoxSettings>(this.defaultSettings))
			{
				this.UISystemChanged();
			}
		}

		public virtual void UISystemChanged()
		{
			DataObject data = this.defaultSettings.GetData();
			this.defaultSettings = Maki.UISystem.settings.Create<BaseDefaultUIBoxSettings>();
			this.defaultSettings.SetData(data);
		}
	}
}
