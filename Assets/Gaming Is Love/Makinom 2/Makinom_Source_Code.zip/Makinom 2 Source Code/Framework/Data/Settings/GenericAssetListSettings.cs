﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public abstract class GenericAssetListSettings : BaseSettings
	{
		public abstract IMakinomGenericAsset GetGenericAssetForGUID(string guid);
	}

	public abstract class GenericAssetListSettings<T, V> : GenericAssetListSettings where T : MakinomGenericAsset<V> where V : BaseIndexData, new()
	{
		// asset reference
		protected List<T> assets = new List<T>();

		protected Dictionary<string, T> guidLookup = new Dictionary<string, T>();

		public override System.Type InstanceType
		{
			get { return typeof(T); }
		}

		public virtual void SetAssets(List<T> data)
		{
			this.assets = data;
		}

		public virtual void AddAsset(T asset)
		{
			asset.Index = this.assets.Count;
			this.assets.Add(asset);
		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			DataObject[] assetData = data.GetFileArray("assets");
			if(assetData != null)
			{
				this.assets.Clear();
				for(int i = 0; i < assetData.Length; i++)
				{
					UnityEngine.Object tmpAsset = null;
					assetData[i].GetAsset("asset", ref tmpAsset);
					T asset = tmpAsset as T;
					if(asset != null)
					{
						// skip this for faster init
						/*if(Application.isPlaying)
						{
							asset.LoadData();
						}*/
						this.assets.Add(asset);
					}
				}
			}
		}

		/// <summary>
		/// Initializes the settings of directly referenced data assets.
		/// </summary>
		public override void InitDataAssetSettings()
		{
			this.guidLookup.Clear();
			for(int i = 0; i < this.assets.Count; i++)
			{
				if(this.assets[i] != null)
				{
					this.assets[i].LoadData();
					while(this.guidLookup.ContainsKey(this.assets[i].Settings.GUID))
					{
						this.assets[i].Settings.GenerateGUID();
					}
					this.guidLookup.Add(this.assets[i].Settings.GUID, this.assets[i]);
				}
			}
		}

		public override DataObject GetData()
		{
			DataObject data = base.GetData();

			DataObject[] assetData = new DataObject[this.assets.Count];
			for(int i = 0; i < assetData.Length; i++)
			{
				assetData[i] = new DataObject();
				assetData[i].SetAsset("asset", (UnityEngine.Object)this.assets[i]);
			}
			data.Set("assets", assetData);

			return data;
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override int Count
		{
			get { return this.assets.Count; }
		}


		/*
		============================================================================
		GUID functions
		============================================================================
		*/
		public virtual void CreateGUIDLookup()
		{
			this.guidLookup.Clear();
			// lookup now created whenever guid is used, otherwise massive data load on init
			// or only do it in application playing > if setdata asset load is needed
			/*for(int i = 0; i < this.assets.Count; i++)
			{
				if(this.assets[i] != null)
				{
					while(this.guidLookup.ContainsKey(this.assets[i].Settings.GUID))
					{
						this.assets[i].Settings.GenerateGUID();
					}
					this.guidLookup.Add(this.assets[i].Settings.GUID, this.assets[i]);
				}
			}*/
		}

		public virtual string IndexToGUID(int index)
		{
			if(index >= 0 &&
				index < this.assets.Count &&
				this.assets[index] != null)
			{
				return this.assets[index].Settings.GUID;
			}
			return "";
		}

		public virtual int GUIDToIndex(string guid)
		{
			T asset = this.GetAssetForGUID(guid);
			if(asset != null)
			{
				return asset.Index;
			}
			return -1;
			/*T asset;
			if(this.guidLookup.TryGetValue(guid, out asset))
			{
				if(asset != null)
				{
					return asset.Index;
				}
			}
			return -1;*/
		}

		public V Get(string guid)
		{
			T asset = this.GetAssetForGUID(guid);
			if(asset != null)
			{
				return asset.Settings;
			}
			return null;
			/*T asset;
			if(this.guidLookup.TryGetValue(guid, out asset))
			{
				if(asset != null)
				{
					return asset.Settings;
				}
			}
			return null;*/
		}

		public T GetAssetForGUID(string guid)
		{
			T asset;
			if(this.guidLookup.TryGetValue(guid, out asset))
			{
				return asset;
			}
			else
			{
				for(int i = 0; i < this.assets.Count; i++)
				{
					if(this.assets[i].Settings.GUID == guid)
					{
						this.guidLookup.Add(guid, this.assets[i]);
						return this.assets[i];
					}
				}
			}
			return null;
		}

		public override IMakinomGenericAsset GetGenericAssetForGUID(string guid)
		{
			return this.GetAssetForGUID(guid);
		}


		/*
		============================================================================
		Add, copy and remove
		============================================================================
		*/
		public V Get(int index)
		{
			if(index >= 0 &&
				index < this.assets.Count &&
				this.assets[index] != null)
			{
				return this.assets[index].Settings;
			}
			return null;
		}

		public T GetAsset(int index)
		{
			if(index >= 0 &&
				index < this.assets.Count &&
				this.assets[index] != null)
			{
				return this.assets[index];
			}
			return null;
		}

		public T Find(string name)
		{
			for(int i = 0; i < this.assets.Count; i++)
			{
				if(this.assets[i] != null &&
					this.assets[i].Settings != null &&
					this.assets[i].Settings.EditorName == name)
				{
					return this.assets[i];
				}
			}
			return null;
		}


		/*
		============================================================================
		Tool functions
		============================================================================
		*/
		public virtual List<string> GetNames()
		{
			List<string> list = new List<string>();
			for(int i = 0; i < this.assets.Count; i++)
			{
				if(this.assets[i] != null &&
					this.assets[i].Settings != null)
				{
					list.Add(this.assets[i].Settings.EditorName);
				}
			}
			return list;
		}
	}
}
