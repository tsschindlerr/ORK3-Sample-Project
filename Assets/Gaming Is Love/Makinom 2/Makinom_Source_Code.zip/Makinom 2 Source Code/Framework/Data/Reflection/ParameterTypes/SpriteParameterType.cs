﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Reflection
{
	[EditorSettingInfo("Sprite", "A sprite.")]
	public class SpriteParameterType<T> : BaseParameterType<T> where T : IObjectSelection, new()
	{
		[EditorHelp("Sprite", "Select the sprite that will be used as parameter.", "")]
		public AssetSource<Sprite> sprite = new AssetSource<Sprite>();

		public SpriteParameterType()
		{

		}

		public override string ToString()
		{
			return this.sprite.ToString();
		}

		public override System.Type GetParameterType()
		{
			return typeof(Sprite);
		}

		public override object GetParameterValue(IDataCall call)
		{
			return this.sprite.StoredAsset;
		}
	}
}
