﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Reflection
{
	[EditorSettingInfo("Component", "A component (attached to a game object).")]
	public class ComponentParameterType<T> : BaseParameterType<T> where T : IObjectSelection, new()
	{
		[EditorTitleLabel("Game Object")]
		public T objectOrigin = new T();

		// component
		[EditorHelp("Component Name", "The name of the component.", "")]
		[EditorWidth(true)]
		[EditorReflectionField(EditorReflectionFieldType.Class, typeof(Component))]
		public string componentName = "";

		[EditorHelp("Scope", "Select the scope of the component that will be used:\n" +
			"- In Object: A component attached to the game object.\n" +
			"- In Children: A component attached to the game object or any child object.\n" +
			"- In Parent: A component attached to the game object or any parent object.\n" +
			"- From Root: A component attached to the game object's root or any child object (from the root).", "")]
		public ComponentScopeSingle componentScope = ComponentScopeSingle.InObject;

		public ComponentParameterType()
		{

		}

		public override string ToString()
		{
			return this.componentName + "(" + this.objectOrigin.ToString() + ")";
		}

		public override bool NeedsCall
		{
			get
			{
				return true;
			}
		}

		public override System.Type GetParameterType()
		{
			return typeof(Component);
		}

		public override object GetParameterValue(IDataCall call)
		{
			List<GameObject> list = this.objectOrigin.GetObjects(call);
			Component component = ComponentHelper.Get(list, this.componentScope, this.componentName);
			Maki.Pooling.GameObjectLists.Add(list);
			return component;
		}
	}
}
