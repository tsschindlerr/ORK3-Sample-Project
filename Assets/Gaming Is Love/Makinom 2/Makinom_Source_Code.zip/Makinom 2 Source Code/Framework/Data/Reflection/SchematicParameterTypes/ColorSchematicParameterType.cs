﻿
using UnityEngine;
using GamingIsLove.Makinom.Schematics;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Reflection
{
	[EditorSettingInfo("Color", "A color value.")]
	public class ColorSchematicParameterType : BaseSchematicParameterType
	{
		[EditorHelp("Color", "Select the color that will be used as parameter.", "")]
		public Color color = Color.white;

		public ColorSchematicParameterType()
		{

		}

		public override string ToString()
		{
			return "Color";
		}

		public override System.Type GetParameterType()
		{
			return typeof(Color);
		}

		public override object GetParameterValue(Schematic schematic)
		{
			return this.color;
		}
	}
}
