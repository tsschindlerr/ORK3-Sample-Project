
using UnityEngine;
using GamingIsLove.Makinom.Schematics;

namespace GamingIsLove.Makinom.Components
{
	[AddComponentMenu("Makinom/Machines/Application Machine")]
	public class ApplicationMachineComponent : BaseMachineComponent, ISerializationCallbackReceiver
	{
		[System.NonSerialized]
		public Settings settings = new Settings();

		[SerializeField]
		[HideInInspector]
		protected ComponentDataFile serialize_setting;

		public override bool CanRestart(GameObject startingObject)
		{
			return this.settings.startSetting.CanStart(this, startingObject);
		}


		/*
		============================================================================
		Application functions
		============================================================================
		*/
		protected virtual void OnApplicationFocus(bool focusStatus)
		{
			if((focusStatus && this.settings.startSetting.isFocusGained &&
					this.settings.startSetting.CanStart(this, Maki.Game.Player.GameObject)) ||
				(!focusStatus && this.settings.startSetting.isFocusLost &&
					this.settings.startSetting.CanStart(this, Maki.Game.Player.GameObject)))
			{
				this.StartMachine(Maki.Game.Player.GameObject,
					this.startVariableSetting.HasStartVariables ?
						this.startVariableSetting.GetStartVariables(
							this.startVariableSetting.NeedsCall ?
								new DataCall(this.gameObject, Maki.Game.Player.GameObject,
									this.assetSetting.inputID.GetInputID(this.gameObject, Maki.Game.Player.GameObject)) : null) :
						null);
			}
		}

		protected virtual void OnApplicationPause(bool pauseStatus)
		{
			if((pauseStatus && this.settings.startSetting.isPaused &&
					this.settings.startSetting.CanStart(this, Maki.Game.Player.GameObject)) ||
				(!pauseStatus && this.settings.startSetting.isUnpaused &&
					this.settings.startSetting.CanStart(this, Maki.Game.Player.GameObject)))
			{
				this.StartMachine(Maki.Game.Player.GameObject,
					this.startVariableSetting.HasStartVariables ?
						this.startVariableSetting.GetStartVariables(
							this.startVariableSetting.NeedsCall ?
								new DataCall(this.gameObject, Maki.Game.Player.GameObject,
									this.assetSetting.inputID.GetInputID(this.gameObject, Maki.Game.Player.GameObject)) : null) :
						null);
			}
		}

		protected virtual void OnApplicationQuit()
		{
			if(this.settings.startSetting.isQuit &&
				this.settings.startSetting.CanStart(this, Maki.Game.Player.GameObject))
			{
				this.StartMachine(Maki.Game.Player.GameObject,
					this.startVariableSetting.HasStartVariables ?
						this.startVariableSetting.GetStartVariables(
							this.startVariableSetting.NeedsCall ?
								new DataCall(this.gameObject, Maki.Game.Player.GameObject,
									this.assetSetting.inputID.GetInputID(this.gameObject, Maki.Game.Player.GameObject)) : null) :
						null);
			}
		}


		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		protected virtual void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "/GamingIsLove/Makinom/Components/ApplicationMachineComponent Icon.png");
		}


		/*
		============================================================================
		Serialization functions
		============================================================================
		*/
		public override void OnBeforeSerialize()
		{
			base.OnBeforeSerialize();
			this.serialize_setting = this.settings.GetData().GetComponentDataFile("settings", false);
		}

		public override void OnAfterDeserialize()
		{
			base.OnAfterDeserialize();
			if(this.serialize_setting != null)
			{
				this.settings.SetData(this.serialize_setting.ToDataObject());
				this.serialize_setting = null;
			}
		}


		/*
		============================================================================
		Settings class
		============================================================================
		*/
		public class Settings : BaseData
		{
			[EditorFoldout("Start Settings", "Define the start settings of this machine.", "")]
			[EditorEndFoldout]
			public ApplicationMachineStartSetting startSetting = new ApplicationMachineStartSetting();

			public Settings()
			{

			}
		}
	}
}
