
using UnityEngine;
using GamingIsLove.Makinom.Schematics;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Components
{
	[AddComponentMenu("Makinom/Machines/Tagged Machine")]
	public class TaggedMachineComponent : BaseMachineComponent, ISerializationCallbackReceiver
	{
		[System.NonSerialized]
		public Settings settings = new Settings();

		[SerializeField]
		[HideInInspector]
		protected ComponentDataFile serialize_setting;


		// in-game
		public static List<TaggedMachineComponent> Available = new List<TaggedMachineComponent>();

		public override bool CanRestart(GameObject startingObject)
		{
			return this.settings.startSetting.CanStart(this, startingObject);
		}

		protected override void OnEnable()
		{
			base.OnEnable();
			TaggedMachineComponent.Available.Add(this);
		}

		protected override void OnDisable()
		{
			base.OnDisable();
			TaggedMachineComponent.Available.Remove(this);
		}


		/*
		============================================================================
		Start tag functions
		============================================================================
		*/
		public virtual bool StartTag(GameObject startingObject, string tag,
			VariableHandler sharedHandler, MachineEnded notify)
		{
			if(this.settings.startSetting.ContainsTag(tag) &&
				this.settings.startSetting.CanStart(this, startingObject))
			{
				this.NotifyEnd(notify);
				if(sharedHandler != null)
				{
					if(this.startVariableSetting.HasStartVariables)
					{
						this.startVariableSetting.AddStartVariables(ref sharedHandler,
							this.startVariableSetting.NeedsCall ?
								new DataCall(this.gameObject, startingObject,
									this.assetSetting.inputID.GetInputID(this.gameObject, startingObject)) : null);
					}
					this.StartMachine(startingObject, sharedHandler);
				}
				else
				{
					this.StartMachine(startingObject,
						this.startVariableSetting.HasStartVariables ?
							this.startVariableSetting.GetStartVariables(
								this.startVariableSetting.NeedsCall ?
									new DataCall(this.gameObject, startingObject,
										this.assetSetting.inputID.GetInputID(this.gameObject, startingObject)) : null) :
							null);
				}
				return true;
			}
			return false;
		}

		public virtual bool StartTag(GameObject startingObject, string[] tags, Needed needed,
			VariableHandler sharedHandler, MachineEnded notify)
		{
			if(this.settings.startSetting.CheckTags(tags, needed) &&
				this.settings.startSetting.CanStart(this, startingObject))
			{
				this.NotifyEnd(notify);
				if(sharedHandler != null)
				{
					if(this.startVariableSetting.HasStartVariables)
					{
						this.startVariableSetting.AddStartVariables(ref sharedHandler,
							this.startVariableSetting.NeedsCall ?
								new DataCall(this.gameObject, startingObject,
									this.assetSetting.inputID.GetInputID(this.gameObject, startingObject)) : null);
					}
					this.StartMachine(startingObject, sharedHandler);
				}
				else
				{
					this.StartMachine(startingObject,
						this.startVariableSetting.HasStartVariables ?
							this.startVariableSetting.GetStartVariables(
								this.startVariableSetting.NeedsCall ?
									new DataCall(this.gameObject, startingObject,
										this.assetSetting.inputID.GetInputID(this.gameObject, startingObject)) : null) :
							null);
				}
				return true;
			}
			return false;
		}

		public virtual bool StartTag(GameObject startingObject, List<string> tags, Needed needed,
			VariableHandler sharedHandler, MachineEnded notify)
		{
			if(this.settings.startSetting.CheckTags(tags, needed) &&
				this.settings.startSetting.CanStart(this, startingObject))
			{
				this.NotifyEnd(notify);
				if(sharedHandler != null)
				{
					if(this.startVariableSetting.HasStartVariables)
					{
						this.startVariableSetting.AddStartVariables(ref sharedHandler,
							this.startVariableSetting.NeedsCall ?
								new DataCall(this.gameObject, startingObject,
									this.assetSetting.inputID.GetInputID(this.gameObject, startingObject)) : null);
					}
					this.StartMachine(startingObject, sharedHandler);
				}
				else
				{
					this.StartMachine(startingObject,
						this.startVariableSetting.HasStartVariables ?
							this.startVariableSetting.GetStartVariables(
								this.startVariableSetting.NeedsCall ?
									new DataCall(this.gameObject, startingObject,
										this.assetSetting.inputID.GetInputID(this.gameObject, startingObject)) : null) :
							null);
				}
				return true;
			}
			return false;
		}

		public static void StartTag(GameObject machineObject, ComponentScope componentScope, 
			GameObject startingObject, string[] tags, Needed needed,
			VariableHandler sharedHandler, MachineEnded notify)
		{
			if(machineObject != null)
			{
				if(ComponentHelper.IsSingleScope(componentScope))
				{
					TaggedMachineComponent taggedMachine = ComponentHelper.GetSingle<TaggedMachineComponent>(machineObject, componentScope);
					if(taggedMachine != null &&
						taggedMachine.isActiveAndEnabled &&
						taggedMachine.settings.startSetting.CheckTags(tags, needed))
					{
						taggedMachine.StartTag(startingObject, tags, needed, sharedHandler, notify);
					}
				}
				else
				{
					TaggedMachineComponent[] taggedMachines = ComponentHelper.GetAll<TaggedMachineComponent>(machineObject, componentScope);
					if(taggedMachines != null)
					{
						for(int i = 0; i < taggedMachines.Length; i++)
						{
							if(taggedMachines[i].isActiveAndEnabled &&
								taggedMachines[i].settings.startSetting.CheckTags(tags, needed))
							{
								taggedMachines[i].StartTag(startingObject, tags, needed, sharedHandler, notify);
							}
						}
					}
				}
			}
		}


		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		protected virtual void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "/GamingIsLove/Makinom/Components/TaggedMachineComponent Icon.png");
		}


		/*
		============================================================================
		Serialization functions
		============================================================================
		*/
		public override void OnBeforeSerialize()
		{
			base.OnBeforeSerialize();
			this.serialize_setting = this.settings.GetData().GetComponentDataFile("settings", false);
		}

		public override void OnAfterDeserialize()
		{
			base.OnAfterDeserialize();
			if(this.serialize_setting != null)
			{
				this.settings.SetData(this.serialize_setting.ToDataObject());
				this.serialize_setting = null;
			}
		}


		/*
		============================================================================
		Settings class
		============================================================================
		*/
		public class Settings : BaseData
		{
			[EditorFoldout("Start Settings", "Define the start settings of this machine.", "")]
			[EditorEndFoldout]
			public TaggedMachineStartSetting startSetting = new TaggedMachineStartSetting();

			public Settings()
			{

			}
		}
	}
}
